#!/usr/bin/perl -w
use strict;

###sourcefilez###
my $filename = 'groups_1.4.txt';

open(FH, $filename)
	or die "Cannot open file '$filename' $!";

my @lines = <FH>;
close FH or die "cant close";

my $groupCount = 0;

my @allsingle = ();
my @uniqueMAG = ();
my @uniqueOKU = ();
my @uniqueCRU = ();
my @onlyOKUmulti = ();
my @onlyMAGmulti = ();
my @onlyCRUmulti = ();
my @multiExceptCRU = ();
my @multiExceptOKU = ();
my @multiExceptMAG = ();
my @allmulti = ();


###print how many groups
my $linesSize = scalar(@lines);
print "You have $linesSize protein famalies.\n\n";



foreach (@lines){
	
	
	my $words = (split / /) - 1;	
	my $sMAG = (split /MAG/) - 1;
	my $sOKU = (split /OKU/) - 1;
	my $sCRU = (split /CRU/) - 1;
	$groupCount += 1;
	
		
	if (($sMAG == 1) & ($sOKU == 1) & ($sCRU == 1)){ push (@allsingle, $groupCount); }
	
	if (($sMAG >= 1) & ($sOKU == 0) & ($sCRU == 0)){ push (@uniqueMAG, $groupCount); }
	if (($sMAG == 0) & ($sOKU >= 1) & ($sCRU == 0)){ push (@uniqueOKU, $groupCount); }
	if (($sMAG == 0) & ($sOKU == 0) & ($sCRU >= 1)){ push (@uniqueCRU, $groupCount); }
	
	if (($sMAG == 1) & ($sOKU >  1) & ($sCRU == 1)){ push (@onlyOKUmulti, $groupCount); }
	if (($sMAG >  1) & ($sOKU == 1) & ($sCRU == 1)){ push (@onlyMAGmulti, $groupCount); }
	if (($sMAG == 1) & ($sOKU == 1) & ($sCRU >  1)){ push (@onlyCRUmulti, $groupCount); }
	
	if (($sMAG >  1) & ($sOKU >  1) & ($sCRU == 1)){ push (@multiExceptCRU, $groupCount); }
	if (($sMAG >  1) & ($sOKU == 1) & ($sCRU >  1)){ push (@multiExceptOKU, $groupCount); }
	if (($sMAG == 1) & ($sOKU >  1) & ($sCRU >  1)){ push (@multiExceptMAG, $groupCount); }
	
	if (($sMAG >  1) & ($sOKU >  1) & ($sCRU >  1)){ push (@allmulti, $groupCount); }
	
	#print "There are $words proteins, $sMAG MAGs, $sOKU OKUs and $sCRU CRUs in group $groupCount \n\n";

	
}

print "The following groups have a single copy in all three species:\n @allsingle\n\n";

print "The following groups are unique to MAG:\n @uniqueMAG\n";
print "The following groups are unique to OKU:\n @uniqueOKU\n";
print "The following groups are unique to CRU:\n @uniqueCRU\n\n";

print "The following groups have a single copy in MAG and CRU but more than one in OKU:\n @onlyOKUmulti\n";
print "The following groups have a single copy in OKU and CRU but more than one in MAG:\n @onlyMAGmulti\n";
print "The following groups have a single copy in MAG and OKU but more than one in CRU:\n @onlyCRUmulti\n\n";

print "The following groups have a single copy in CRU but more than one in MAG and OKU:\n @multiExceptCRU\n";
print "The following groups have a single copy in OKU but more than one in MAG and CRU:\n @multiExceptOKU\n";
print "The following groups have a single copy in MAG but more than one in OKU and CRU:\n @multiExceptMAG\n\n";

print "The following groups have more than one copy in all three species:\n @allmulti\n\n\n";



print "There are ".scalar(@allsingle). " groups that have a single copy in all three species\n\n";

print "There are ".scalar(@uniqueMAG). " groups that are unique to MAG\n";
print "There are ".scalar(@uniqueOKU). " groups that are unique to OKU\n";
print "There are ".scalar(@uniqueCRU). " groups that are unique to CRU\n\n";

print "There are ".scalar(@onlyOKUmulti). " groups that have a single copy in MAG and CRU and multiple copies in OKU\n";
print "There are ".scalar(@onlyMAGmulti). " groups that have a single copy in OKU and CRU and multiple copies in MAG\n";
print "There are ".scalar(@onlyCRUmulti). " groups that have a single copy in MAG and OKU and multiple copies in CRU\n\n";

print "There are ".scalar(@multiExceptCRU). " groups that have a single copy in CRU and multiple copies in MAG and OKU\n";
print "There are ".scalar(@multiExceptOKU). " groups that have a single copy in OKU and multiple copies in MAG and CRU\n";
print "There are ".scalar(@multiExceptMAG). " groups that have a single copy in MAG and multiple copies in OKU and CRU\n\n";

print "There are ".scalar(@allmulti). " groups that have multiple copies in all three species\n\n\n";

print "done\n";
exit 0;
